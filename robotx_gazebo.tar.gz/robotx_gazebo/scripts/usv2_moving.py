#!/usr/bin/env python
# coding=utf-8
# publish the velocity to the cmd_vel
import rospy
from geometry_msgs.msg import Twist
def velocity_publisher():
    #init node
    rospy.init_node('velocity_publisher', anonymous=True)
    #creat a publisher, publish the topic /cmd_vel， msg: geometry_msgs:Twist, The queue length is ten
    pub = rospy.Publisher('cmd_vel',Twist,queue_size=10)
    #set cycle frequency
    rate = rospy.Rate(10)

    while not rospy.is_shutdown():
        vel_msg = Twist()
        vel_msg.linear.x= 1
        vel_msg.angular.z= 0
        #publish the msg
        pub.publish(vel_msg)
        rospy.loginfo("publish usv velocity command[%0.2f m/s, %0.2f rad/s]",vel_msg.linear.x,vel_msg.angular.z)
        #delay as the cycle frequency
        rate.sleep()
if __name__== '__main__':
    try:
        velocity_publisher()
    except rospy.ROSInternalException:
        pass

